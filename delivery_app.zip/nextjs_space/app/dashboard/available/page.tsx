'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loading } from '@/components/shared/loading';
import { EmptyState } from '@/components/shared/empty-state';
import { StatusBadge } from '@/components/shared/status-badge';
import { useToast } from '@/hooks/use-toast';
import { Package, MapPin, Navigation, DollarSign, User, Loader2, CheckCircle } from 'lucide-react';
import { useRouter } from 'next/navigation';

interface Order {
  id: string;
  originAddress: string;
  destinationAddress: string;
  notes?: string;
  status: string;
  price: number;
  distance: number;
  createdAt: string;
  client: { name: string; phone?: string };
  transactions: Array<{
    deliveryFee: number;
  }>;
}

export default function AvailableOrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [acceptingOrderId, setAcceptingOrderId] = useState<string | null>(null);
  const { toast } = useToast();
  const router = useRouter();

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/orders/available');

      if (res.ok) {
        const data = await res.json();
        setOrders(data?.orders ?? []);
      }
    } catch (error) {
      console.error('Error fetching available orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAcceptOrder = async (orderId: string) => {
    setAcceptingOrderId(orderId);
    try {
      const res = await fetch(`/api/orders/${orderId}/accept`, {
        method: 'POST',
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data?.error || 'Erro ao aceitar pedido');
      }

      toast({
        title: 'Sucesso!',
        description: 'Pedido aceito! Você pode vê-lo em Minhas Entregas.',
      });

      router.push('/dashboard/my-deliveries');
    } catch (error: any) {
      toast({
        title: 'Erro',
        description: error?.message || 'Erro ao aceitar pedido',
        variant: 'destructive',
      });
      // Refresh the list
      fetchOrders();
    } finally {
      setAcceptingOrderId(null);
    }
  };

  if (loading) {
    return <Loading />;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Pedidos Disponíveis</h1>
        <p className="text-muted-foreground">
          Aceite pedidos para começar a entregar e ganhar
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Pedidos Aguardando Entregador</CardTitle>
          <CardDescription>Total: {orders?.length ?? 0} pedidos disponíveis</CardDescription>
        </CardHeader>
        <CardContent>
          {orders?.length === 0 ? (
            <EmptyState
              icon={Package}
              title="Nenhum pedido disponível"
              description="No momento não há pedidos aguardando entregador. Volte mais tarde!"
            />
          ) : (
            <div className="space-y-4">
              {orders?.map((order) => (
                <Card key={order.id} className="border-blue-200 bg-blue-50/30">
                  <CardContent className="p-6 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center space-x-3">
                          <StatusBadge status={order.status as any} type="order" />
                          <span className="text-sm text-muted-foreground">
                            {new Date(order.createdAt).toLocaleString('pt-BR')}
                          </span>
                        </div>

                        <div className="space-y-3 mt-4">
                          <div className="flex items-start space-x-3">
                            <MapPin className="w-5 h-5 text-blue-600 mt-1" />
                            <div>
                              <p className="font-medium text-sm">Origem</p>
                              <p className="text-muted-foreground">{order.originAddress}</p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-3">
                            <Navigation className="w-5 h-5 text-orange-600 mt-1" />
                            <div>
                              <p className="font-medium text-sm">Destino</p>
                              <p className="text-muted-foreground">
                                {order.destinationAddress}
                              </p>
                            </div>
                          </div>
                        </div>

                        {order?.notes && (
                          <div className="pt-2 mt-2 border-t">
                            <p className="font-medium text-sm">Observações</p>
                            <p className="text-sm text-muted-foreground">{order.notes}</p>
                          </div>
                        )}

                        <div className="flex items-center space-x-4 pt-2 text-sm">
                          <div className="flex items-center space-x-2">
                            <User className="w-4 h-4 text-muted-foreground" />
                            <span>{order?.client?.name}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Navigation className="w-4 h-4 text-muted-foreground" />
                            <span>{order.distance} km</span>
                          </div>
                        </div>
                      </div>

                      <div className="ml-6 text-right space-y-4">
                        <div>
                          <p className="text-sm text-muted-foreground mb-1">Você ganha</p>
                          <p className="font-bold text-2xl text-green-600">
                            R$ {order?.transactions?.[0]?.deliveryFee?.toFixed(2) ?? '0.00'}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Total: R$ {order?.price?.toFixed(2) ?? '0.00'}
                          </p>
                        </div>

                        <Button
                          onClick={() => handleAcceptOrder(order.id)}
                          disabled={acceptingOrderId !== null}
                          className="w-full"
                        >
                          {acceptingOrderId === order.id ? (
                            <>
                              <Loader2 className="w-4 h-4 animate-spin" />
                              Aceitando...
                            </>
                          ) : (
                            <>
                              <CheckCircle className="w-4 h-4" />
                              Aceitar Pedido
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
