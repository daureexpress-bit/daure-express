'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loading } from '@/components/shared/loading';
import { StatusBadge } from '@/components/shared/status-badge';
import { useToast } from '@/hooks/use-toast';
import {
  MapPin,
  Navigation,
  DollarSign,
  User,
  Phone,
  Star,
  Clock,
  CheckCircle,
  Loader2,
} from 'lucide-react';
import { UserRole } from '@prisma/client';

interface Order {
  id: string;
  originAddress: string;
  destinationAddress: string;
  notes?: string;
  status: string;
  price: number;
  distance: number;
  createdAt: string;
  acceptedAt?: string;
  pickedUpAt?: string;
  inTransitAt?: string;
  completedAt?: string;
  client: { id: string; name: string; email: string; phone?: string };
  deliveryPerson?: { id: string; name: string; phone?: string; rating?: number };
  transactions: Array<{
    totalAmount: number;
    platformFee: number;
    deliveryFee: number;
    paymentMethod: string;
    paymentStatus: string;
  }>;
  rating?: {
    rating: number;
    comment?: string;
    createdAt: string;
  };
}

export default function OrderDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [showRatingForm, setShowRatingForm] = useState(false);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [isSubmittingRating, setIsSubmittingRating] = useState(false);

  const orderId = params?.id as string;

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const res = await fetch(`/api/orders/${orderId}`);

        if (res.ok) {
          const data = await res.json();
          setOrder(data?.order ?? null);
        } else {
          toast({
            title: 'Erro',
            description: 'Pedido não encontrado',
            variant: 'destructive',
          });
          router.push('/dashboard/orders');
        }
      } catch (error) {
        console.error('Error fetching order:', error);
      } finally {
        setLoading(false);
      }
    };

    if (orderId) {
      fetchOrder();
    }
  }, [orderId, router, toast]);

  const handleSubmitRating = async () => {
    setIsSubmittingRating(true);
    try {
      const res = await fetch('/api/ratings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: order?.id,
          rating,
          comment,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data?.error || 'Erro ao enviar avaliação');
      }

      toast({
        title: 'Sucesso!',
        description: 'Avaliação registrada com sucesso',
      });

      // Refresh order data
      const refreshRes = await fetch(`/api/orders/${orderId}`);
      if (refreshRes.ok) {
        const refreshData = await refreshRes.json();
        setOrder(refreshData?.order ?? null);
      }

      setShowRatingForm(false);
    } catch (error: any) {
      toast({
        title: 'Erro',
        description: error?.message || 'Erro ao enviar avaliação',
        variant: 'destructive',
      });
    } finally {
      setIsSubmittingRating(false);
    }
  };

  if (loading) {
    return <Loading />;
  }

  if (!order) {
    return <div>Pedido não encontrado</div>;
  }

  // Can rate if order is delivered, not yet rated, and has delivery person
  const canRate =
    order.status === 'DELIVERED' &&
    !order?.rating &&
    order?.deliveryPerson;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Detalhes do Pedido</h1>
          <p className="text-muted-foreground">Pedido #{order.id.slice(0, 8)}</p>
        </div>
        <StatusBadge status={order.status as any} type="order" />
      </div>

      {/* Addresses */}
      <Card>
        <CardHeader>
          <CardTitle>Endereços</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start space-x-3">
            <MapPin className="w-5 h-5 text-blue-600 mt-1" />
            <div>
              <p className="font-medium">Origem</p>
              <p className="text-muted-foreground">{order.originAddress}</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <Navigation className="w-5 h-5 text-orange-600 mt-1" />
            <div>
              <p className="font-medium">Destino</p>
              <p className="text-muted-foreground">{order.destinationAddress}</p>
            </div>
          </div>
          {order?.notes && (
            <div className="pt-2 border-t">
              <p className="font-medium mb-1">Observações</p>
              <p className="text-muted-foreground">{order.notes}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Timeline */}
      <Card>
        <CardHeader>
          <CardTitle>Linha do Tempo</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="font-medium">Pedido Criado</p>
                <p className="text-sm text-muted-foreground">
                  {new Date(order.createdAt).toLocaleString('pt-BR')}
                </p>
              </div>
            </div>
            {order?.acceptedAt && (
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium">Aceito pelo Entregador</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(order.acceptedAt).toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>
            )}
            {order?.pickedUpAt && (
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-indigo-600" />
                </div>
                <div>
                  <p className="font-medium">Coletado</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(order.pickedUpAt).toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>
            )}
            {order?.inTransitAt && (
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="font-medium">Em Trânsito</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(order.inTransitAt).toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>
            )}
            {order?.completedAt && (
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="font-medium">Entregue</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(order.completedAt).toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* People Involved */}
      <div className="grid md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <User className="w-5 h-5" />
              <span>Cliente</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="font-medium">{order?.client?.name}</p>
            <p className="text-sm text-muted-foreground">{order?.client?.email}</p>
            {order?.client?.phone && (
              <p className="text-sm text-muted-foreground flex items-center space-x-2">
                <Phone className="w-4 h-4" />
                <span>{order.client.phone}</span>
              </p>
            )}
          </CardContent>
        </Card>

        {order?.deliveryPerson && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <User className="w-5 h-5" />
                <span>Entregador</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <p className="font-medium">{order.deliveryPerson.name}</p>
              {order?.deliveryPerson?.phone && (
                <p className="text-sm text-muted-foreground flex items-center space-x-2">
                  <Phone className="w-4 h-4" />
                  <span>{order.deliveryPerson.phone}</span>
                </p>
              )}
              {order?.deliveryPerson?.rating !== undefined &&
                order?.deliveryPerson?.rating !== null && (
                  <p className="text-sm flex items-center space-x-2">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    <span>{order.deliveryPerson.rating.toFixed(1)}</span>
                  </p>
                )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Payment */}
      {order?.transactions?.[0] && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <DollarSign className="w-5 h-5" />
              <span>Pagamento</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Distância</span>
              <span className="font-medium">{order.distance} km</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Taxa de Entrega</span>
              <span className="font-medium">
                R$ {order?.transactions?.[0]?.deliveryFee?.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Taxa da Plataforma</span>
              <span className="font-medium">
                R$ {order?.transactions?.[0]?.platformFee?.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between pt-3 border-t">
              <span className="font-semibold text-lg">Total</span>
              <span className="font-bold text-2xl text-green-600">
                R$ {order?.transactions?.[0]?.totalAmount?.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-muted-foreground">Método</span>
              <StatusBadge
                status={order?.transactions?.[0]?.paymentMethod as any}
                type="payment"
              />
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-muted-foreground">Status</span>
              <StatusBadge
                status={order?.transactions?.[0]?.paymentStatus as any}
                type="payment"
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Rating Section */}
      {order?.rating ? (
        <Card className="border-yellow-200 bg-yellow-50/50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Star className="w-5 h-5 text-yellow-600" />
              <span>Avaliação</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center space-x-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-6 h-6 ${
                    star <= (order?.rating?.rating ?? 0)
                      ? 'text-yellow-500 fill-yellow-500'
                      : 'text-gray-300'
                  }`}
                />
              ))}
              <span className="font-medium text-lg">{order?.rating?.rating}/5</span>
            </div>
            {order?.rating?.comment && (
              <div>
                <p className="font-medium mb-1">Comentário</p>
                <p className="text-muted-foreground">{order.rating.comment}</p>
              </div>
            )}
            <p className="text-sm text-muted-foreground">
              Avaliado em {new Date(order?.rating?.createdAt).toLocaleDateString('pt-BR')}
            </p>
          </CardContent>
        </Card>
      ) : canRate && !showRatingForm ? (
        <Card>
          <CardHeader>
            <CardTitle>Avalie o Entregador</CardTitle>
            <CardDescription>
              Sua opinião é importante para melhorar nosso serviço
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => setShowRatingForm(true)} className="w-full">
              <Star className="w-4 h-4" />
              Avaliar Entrega
            </Button>
          </CardContent>
        </Card>
      ) : canRate && showRatingForm ? (
        <Card>
          <CardHeader>
            <CardTitle>Avaliar Entregador</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Nota (1-5)</Label>
              <div className="flex items-center space-x-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="focus:outline-none"
                  >
                    <Star
                      className={`w-8 h-8 cursor-pointer transition-colors ${
                        star <= rating
                          ? 'text-yellow-500 fill-yellow-500'
                          : 'text-gray-300 hover:text-yellow-400'
                      }`}
                    />
                  </button>
                ))}
                <span className="font-medium ml-2">{rating}/5</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="comment">Comentário (opcional)</Label>
              <Textarea
                id="comment"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Conte-nos sobre sua experiência..."
                className="min-h-[100px]"
              />
            </div>
            <div className="flex space-x-2">
              <Button
                onClick={handleSubmitRating}
                disabled={isSubmittingRating}
                className="flex-1"
              >
                {isSubmittingRating ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  'Enviar Avaliação'
                )}
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowRatingForm(false)}
                disabled={isSubmittingRating}
              >
                Cancelar
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
