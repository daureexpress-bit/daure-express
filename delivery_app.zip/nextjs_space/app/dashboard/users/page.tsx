'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loading } from '@/components/shared/loading';
import { EmptyState } from '@/components/shared/empty-state';
import { StatusBadge } from '@/components/shared/status-badge';
import { useToast } from '@/hooks/use-toast';
import { Users, Filter, CheckCircle, XCircle, Loader2, Star } from 'lucide-react';
import { USER_ROLE_LABELS } from '@/lib/constants';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  status: string;
  phone?: string;
  vehicleType?: string;
  licenseNumber?: string;
  rating?: number;
  totalDeliveries?: number;
  createdAt: string;
}

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [roleFilter, setRoleFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [updatingUserId, setUpdatingUserId] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchUsers();
  }, [roleFilter, statusFilter]);

  const fetchUsers = async () => {
    try {
      const params = new URLSearchParams();
      if (roleFilter !== 'ALL') params.append('role', roleFilter);
      if (statusFilter !== 'ALL') params.append('status', statusFilter);

      const res = await fetch(`/api/users?${params.toString()}`);

      if (res.ok) {
        const data = await res.json();
        setUsers(data?.users ?? []);
      }
    } catch (error) {
      console.error('Error fetching users:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateUserStatus = async (userId: string, newStatus: string) => {
    setUpdatingUserId(userId);
    try {
      const res = await fetch(`/api/users/${userId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data?.error || 'Erro ao atualizar status');
      }

      toast({
        title: 'Sucesso!',
        description: 'Status do usuário atualizado',
      });

      fetchUsers();
    } catch (error: any) {
      toast({
        title: 'Erro',
        description: error?.message || 'Erro ao atualizar status',
        variant: 'destructive',
      });
    } finally {
      setUpdatingUserId(null);
    }
  };

  if (loading) {
    return <Loading />;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Gerenciar Usuários</h1>
        <p className="text-muted-foreground">
          Aprove, edite ou bloqueie usuários da plataforma
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Lista de Usuários</CardTitle>
              <CardDescription>Total: {users?.length ?? 0} usuários</CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="h-9 rounded-md border border-input bg-background px-3 text-sm"
              >
                <option value="ALL">Todos os Perfis</option>
                <option value="CLIENT">Clientes</option>
                <option value="DELIVERY_PERSON">Entregadores</option>
                <option value="ADMIN">Administradores</option>
              </select>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="h-9 rounded-md border border-input bg-background px-3 text-sm"
              >
                <option value="ALL">Todos Status</option>
                <option value="ACTIVE">Ativos</option>
                <option value="PENDING_APPROVAL">Aguardando Aprovação</option>
                <option value="BLOCKED">Bloqueados</option>
              </select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {users?.length === 0 ? (
            <EmptyState
              icon={Users}
              title="Nenhum usuário encontrado"
              description="Nenhum usuário corresponde aos filtros selecionados"
            />
          ) : (
            <div className="space-y-4">
              {users?.map((user) => (
                <Card key={user.id} className="border-muted">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 space-y-3">
                        <div className="flex items-center space-x-3">
                          <div>
                            <p className="font-semibold text-lg">{user.name}</p>
                            <p className="text-sm text-muted-foreground">{user.email}</p>
                          </div>
                        </div>

                        <div className="flex items-center space-x-4">
                          <StatusBadge status={user.role as any} type="user" />
                          <StatusBadge status={user.status as any} type="user" />
                        </div>

                        {user?.phone && (
                          <p className="text-sm text-muted-foreground">Telefone: {user.phone}</p>
                        )}

                        {user.role === 'DELIVERY_PERSON' && (
                          <div className="space-y-1">
                            {user?.vehicleType && (
                              <p className="text-sm text-muted-foreground">
                                Veículo: {user.vehicleType}
                              </p>
                            )}
                            {user?.licenseNumber && (
                              <p className="text-sm text-muted-foreground">
                                CNH: {user.licenseNumber}
                              </p>
                            )}
                            <div className="flex items-center space-x-4">
                              {user?.rating !== undefined && user?.rating !== null && (
                                <div className="flex items-center space-x-1">
                                  <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                                  <span className="text-sm">{user.rating.toFixed(1)}</span>
                                </div>
                              )}
                              <p className="text-sm text-muted-foreground">
                                {user?.totalDeliveries ?? 0} entregas
                              </p>
                            </div>
                          </div>
                        )}

                        <p className="text-xs text-muted-foreground">
                          Cadastrado em {new Date(user.createdAt).toLocaleDateString('pt-BR')}
                        </p>
                      </div>

                      <div className="ml-6 space-y-2">
                        {user.status === 'PENDING_APPROVAL' && (
                          <Button
                            size="sm"
                            onClick={() => handleUpdateUserStatus(user.id, 'ACTIVE')}
                            disabled={updatingUserId !== null}
                            className="w-full"
                          >
                            {updatingUserId === user.id ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <>
                                <CheckCircle className="w-4 h-4" />
                                Aprovar
                              </>
                            )}
                          </Button>
                        )}

                        {user.status === 'ACTIVE' && (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleUpdateUserStatus(user.id, 'BLOCKED')}
                            disabled={updatingUserId !== null}
                            className="w-full"
                          >
                            {updatingUserId === user.id ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <>
                                <XCircle className="w-4 h-4" />
                                Bloquear
                              </>
                            )}
                          </Button>
                        )}

                        {user.status === 'BLOCKED' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUpdateUserStatus(user.id, 'ACTIVE')}
                            disabled={updatingUserId !== null}
                            className="w-full"
                          >
                            {updatingUserId === user.id ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <>
                                <CheckCircle className="w-4 h-4" />
                                Reativar
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
