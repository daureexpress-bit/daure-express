'use client';

import dynamic from 'next/dynamic';

const Navbar = dynamic(() => import('@/components/shared/navbar').then((mod) => ({ default: mod.Navbar })), {
  ssr: false,
});

export function DashboardLayoutClient({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50/30 via-white to-orange-50/30">
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">{children}</main>
    </div>
  );
}
