'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loading } from '@/components/shared/loading';
import { StatusBadge } from '@/components/shared/status-badge';
import { useToast } from '@/hooks/use-toast';
import {
  MapPin,
  Navigation,
  User,
  Phone,
  Clock,
  Package,
  TruckIcon,
  CheckCircle,
  Loader2,
} from 'lucide-react';

interface Order {
  id: string;
  originAddress: string;
  destinationAddress: string;
  notes?: string;
  status: string;
  price: number;
  distance: number;
  createdAt: string;
  acceptedAt?: string;
  pickedUpAt?: string;
  inTransitAt?: string;
  completedAt?: string;
  client: { name: string; email: string; phone?: string };
  transactions: Array<{
    deliveryFee: number;
    totalAmount: number;
  }>;
}

export default function DeliveryDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [updatingStatus, setUpdatingStatus] = useState(false);

  const orderId = params?.id as string;

  useEffect(() => {
    fetchOrder();
  }, [orderId]);

  const fetchOrder = async () => {
    try {
      const res = await fetch(`/api/orders/${orderId}`);

      if (res.ok) {
        const data = await res.json();
        setOrder(data?.order ?? null);
      } else {
        toast({
          title: 'Erro',
          description: 'Pedido não encontrado',
          variant: 'destructive',
        });
        router.push('/dashboard/my-deliveries');
      }
    } catch (error) {
      console.error('Error fetching order:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (newStatus: string) => {
    setUpdatingStatus(true);
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data?.error || 'Erro ao atualizar status');
      }

      toast({
        title: 'Sucesso!',
        description: 'Status atualizado com sucesso',
      });

      // Refresh order data
      fetchOrder();
    } catch (error: any) {
      toast({
        title: 'Erro',
        description: error?.message || 'Erro ao atualizar status',
        variant: 'destructive',
      });
    } finally {
      setUpdatingStatus(false);
    }
  };

  const getNextStatusButton = () => {
    if (!order) return null;

    const statusActions: Record<string, { status: string; label: string; icon: any }> = {
      ACCEPTED: {
        status: 'PICKED_UP',
        label: 'Marcar como Coletado',
        icon: Package,
      },
      PICKED_UP: {
        status: 'IN_TRANSIT',
        label: 'Iniciar Transporte',
        icon: TruckIcon,
      },
      IN_TRANSIT: {
        status: 'DELIVERED',
        label: 'Confirmar Entrega',
        icon: CheckCircle,
      },
    };

    const action = statusActions[order.status];
    if (!action) return null;

    const Icon = action.icon;

    return (
      <Button
        onClick={() => handleUpdateStatus(action.status)}
        disabled={updatingStatus}
        size="lg"
        className="w-full"
      >
        {updatingStatus ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            Atualizando...
          </>
        ) : (
          <>
            <Icon className="w-5 h-5" />
            {action.label}
          </>
        )}
      </Button>
    );
  };

  if (loading) {
    return <Loading />;
  }

  if (!order) {
    return <div>Pedido não encontrado</div>;
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Detalhes da Entrega</h1>
          <p className="text-muted-foreground">Pedido #{order.id.slice(0, 8)}</p>
        </div>
        <StatusBadge status={order.status as any} type="order" />
      </div>

      {/* Action Button */}
      {order.status !== 'DELIVERED' && order.status !== 'CANCELLED' && (
        <Card className="border-green-200 bg-green-50/50">
          <CardContent className="p-6">{getNextStatusButton()}</CardContent>
        </Card>
      )}

      {/* Earnings */}
      <Card className="border-green-200 bg-green-50/30">
        <CardHeader>
          <CardTitle>Seus Ganhos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground mb-1">Você recebe</p>
              <p className="font-bold text-3xl text-green-600">
                R$ {order?.transactions?.[0]?.deliveryFee?.toFixed(2) ?? '0.00'}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Total do pedido</p>
              <p className="font-medium text-lg">
                R$ {order?.transactions?.[0]?.totalAmount?.toFixed(2) ?? '0.00'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Addresses */}
      <Card>
        <CardHeader>
          <CardTitle>Endereços</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start space-x-3">
            <MapPin className="w-5 h-5 text-blue-600 mt-1" />
            <div>
              <p className="font-medium">Origem</p>
              <p className="text-muted-foreground">{order.originAddress}</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <Navigation className="w-5 h-5 text-orange-600 mt-1" />
            <div>
              <p className="font-medium">Destino</p>
              <p className="text-muted-foreground">{order.destinationAddress}</p>
            </div>
          </div>
          <div className="pt-2 border-t">
            <p className="font-medium mb-1">Distância</p>
            <p className="text-muted-foreground">{order.distance} km</p>
          </div>
          {order?.notes && (
            <div className="pt-2 border-t">
              <p className="font-medium mb-1">Observações do Cliente</p>
              <p className="text-muted-foreground">{order.notes}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Client Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="w-5 h-5" />
            <span>Informações do Cliente</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <p className="font-medium">{order?.client?.name}</p>
          <p className="text-sm text-muted-foreground">{order?.client?.email}</p>
          {order?.client?.phone && (
            <div className="flex items-center space-x-2 pt-2">
              <Phone className="w-4 h-4" />
              <a
                href={`tel:${order.client.phone}`}
                className="text-blue-600 hover:underline"
              >
                {order.client.phone}
              </a>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Timeline */}
      <Card>
        <CardHeader>
          <CardTitle>Linha do Tempo</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {order?.acceptedAt && (
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="font-medium">Pedido Aceito</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(order.acceptedAt).toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>
            )}
            {order?.pickedUpAt && (
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                  <Package className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium">Coletado</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(order.pickedUpAt).toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>
            )}
            {order?.inTransitAt && (
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
                  <TruckIcon className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="font-medium">Em Trânsito</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(order.inTransitAt).toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>
            )}
            {order?.completedAt && (
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="font-medium">Entregue</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(order.completedAt).toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
