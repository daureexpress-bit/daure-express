'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { MapPin, Navigation, FileText, DollarSign, Loader2, CreditCard } from 'lucide-react';

export default function NewOrderPage() {
  const [formData, setFormData] = useState({
    originAddress: '',
    destinationAddress: '',
    notes: '',
    paymentMethod: 'CREDIT_CARD',
  });
  const [estimate, setEstimate] = useState<any>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
    // Clear estimate when addresses change
    if (e.target.name === 'originAddress' || e.target.name === 'destinationAddress') {
      setEstimate(null);
    }
  };

  const handleCalculatePrice = async () => {
    if (!formData.originAddress || !formData.destinationAddress) {
      toast({
        title: 'Erro',
        description: 'Preencha os endereços de origem e destino',
        variant: 'destructive',
      });
      return;
    }

    setIsCalculating(true);
    try {
      const res = await fetch('/api/calculate-price', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          originAddress: formData.originAddress,
          destinationAddress: formData.destinationAddress,
        }),
      });

      if (!res.ok) {
        throw new Error('Erro ao calcular preço');
      }

      const data = await res.json();
      setEstimate(data);
    } catch (error: any) {
      toast({
        title: 'Erro',
        description: error?.message || 'Erro ao calcular preço',
        variant: 'destructive',
      });
    } finally {
      setIsCalculating(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!estimate) {
      toast({
        title: 'Erro',
        description: 'Calcule o preço antes de criar o pedido',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data?.error || 'Erro ao criar pedido');
      }

      toast({
        title: 'Sucesso!',
        description: 'Pedido criado com sucesso',
      });

      router.push(`/dashboard/orders/${data?.order?.id}`);
    } catch (error: any) {
      toast({
        title: 'Erro',
        description: error?.message || 'Erro ao criar pedido',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Novo Pedido</h1>
        <p className="text-muted-foreground">Crie uma solicitação de coleta e entrega</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Detalhes da Entrega</CardTitle>
            <CardDescription>Informe os endereços de origem e destino</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="originAddress">Endereço de Origem</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="originAddress"
                  name="originAddress"
                  placeholder="Rua, número, bairro, cidade"
                  value={formData.originAddress}
                  onChange={handleChange}
                  required
                  className="pl-10"
                  disabled={isSubmitting}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="destinationAddress">Endereço de Destino</Label>
              <div className="relative">
                <Navigation className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="destinationAddress"
                  name="destinationAddress"
                  placeholder="Rua, número, bairro, cidade"
                  value={formData.destinationAddress}
                  onChange={handleChange}
                  required
                  className="pl-10"
                  disabled={isSubmitting}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Observações (opcional)</Label>
              <div className="relative">
                <FileText className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Textarea
                  id="notes"
                  name="notes"
                  placeholder="Instruções especiais, ponto de referência, etc."
                  value={formData.notes}
                  onChange={handleChange}
                  className="pl-10 min-h-[100px]"
                  disabled={isSubmitting}
                />
              </div>
            </div>

            <Button
              type="button"
              onClick={handleCalculatePrice}
              variant="outline"
              className="w-full"
              disabled={isCalculating || isSubmitting}
            >
              {isCalculating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Calculando...
                </>
              ) : (
                <>
                  <DollarSign className="w-4 h-4" />
                  Calcular Preço
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {estimate && (
          <Card className="border-green-200 bg-green-50/50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <DollarSign className="w-5 h-5 text-green-600" />
                <span>Estimativa de Preço</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Distância:</span>
                <span className="font-medium">{estimate?.distance} km</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Taxa de Entrega:</span>
                <span className="font-medium">R$ {estimate?.deliveryFee?.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Taxa da Plataforma:</span>
                <span className="font-medium">R$ {estimate?.platformFee?.toFixed(2)}</span>
              </div>
              <div className="border-t pt-3 flex justify-between items-center">
                <span className="font-semibold text-lg">Total:</span>
                <span className="font-bold text-2xl text-green-600">
                  R$ {estimate?.price?.toFixed(2)}
                </span>
              </div>
            </CardContent>
          </Card>
        )}

        {estimate && (
          <Card>
            <CardHeader>
              <CardTitle>Pagamento</CardTitle>
              <CardDescription>Selecione o método de pagamento (simulado)</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="paymentMethod">Método de Pagamento</Label>
                <select
                  id="paymentMethod"
                  name="paymentMethod"
                  value={formData.paymentMethod}
                  onChange={handleChange}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  disabled={isSubmitting}
                >
                  <option value="CREDIT_CARD">Cartão de Crédito</option>
                  <option value="DEBIT_CARD">Cartão de Débito</option>
                  <option value="PIX">PIX</option>
                </select>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>Nota:</strong> O pagamento é simulado nesta versão. Nenhuma transação real será processada.
                </p>
              </div>

              <Button type="submit" className="w-full" size="lg" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Criando Pedido...
                  </>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4" />
                    Confirmar e Criar Pedido
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        )}
      </form>
    </div>
  );
}
