import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';
import { UserRole, OrderStatus, PaymentStatus } from '@prisma/client';
import { calculateDistance, calculateOrderPrice } from '@/lib/price-calculator';
import { createAuditLog } from '@/lib/audit-logger';

export const dynamic = 'force-dynamic';

// GET orders
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status');
    const limit = searchParams.get('limit');

    const where: any = {};

    // Apply filters based on role
    if (session.user.role === UserRole.CLIENT) {
      where.clientId = session.user.id;
    } else if (session.user.role === UserRole.DELIVERY_PERSON) {
      where.deliveryPersonId = session.user.id;
    }
    // ADMIN can see all orders (no filter)

    if (status) {
      where.status = status;
    }

    const orders = await prisma.order.findMany({
      where,
      include: {
        client: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
          },
        },
        deliveryPerson: {
          select: {
            id: true,
            name: true,
            phone: true,
            vehicleType: true,
            rating: true,
          },
        },
        transactions: true,
        rating: true,
      },
      orderBy: { createdAt: 'desc' },
      take: limit ? parseInt(limit) : undefined,
    });

    return NextResponse.json({ orders });
  } catch (error) {
    console.error('Error fetching orders:', error);
    return NextResponse.json(
      { error: 'Erro ao buscar pedidos' },
      { status: 500 }
    );
  }
}

// POST create order (CLIENT only)
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });
    }

    if (session.user.role !== UserRole.CLIENT) {
      return NextResponse.json(
        { error: 'Apenas clientes podem criar pedidos' },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { originAddress, destinationAddress, notes, paymentMethod } = body;

    if (!originAddress || !destinationAddress) {
      return NextResponse.json(
        { error: 'Endereços de origem e destino são obrigatórios' },
        { status: 400 }
      );
    }

    // Calculate distance (simulated)
    const distance = calculateDistance(originAddress, destinationAddress);

    // Calculate price
    const { price, platformFee, deliveryFee } = await calculateOrderPrice(distance);

    // Create order and transaction in a transaction
    const order = await prisma.$transaction(async (tx) => {
      const newOrder = await tx.order.create({
        data: {
          clientId: session.user.id,
          originAddress,
          destinationAddress,
          notes,
          distance,
          price,
          status: OrderStatus.PENDING,
        },
        include: {
          client: {
            select: {
              id: true,
              name: true,
              email: true,
              phone: true,
            },
          },
        },
      });

      // Create transaction (simulated payment)
      await tx.transaction.create({
        data: {
          orderId: newOrder.id,
          totalAmount: price,
          platformFee,
          deliveryFee,
          paymentStatus: PaymentStatus.COMPLETED, // Simulated payment
          paymentMethod: paymentMethod || 'CREDIT_CARD',
        },
      });

      return newOrder;
    });

    // Log the action
    await createAuditLog({
      userId: session.user.id,
      orderId: order.id,
      action: 'ORDER_CREATED',
      details: `Order created with price R$ ${price}`,
      ipAddress: req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || undefined,
      userAgent: req.headers.get('user-agent') || undefined,
    });

    return NextResponse.json(
      {
        order,
        message: 'Pedido criado com sucesso!',
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Error creating order:', error);
    return NextResponse.json(
      { error: 'Erro ao criar pedido' },
      { status: 500 }
    );
  }
}
