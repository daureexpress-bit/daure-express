import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { calculateDistance, calculateOrderPrice } from '@/lib/price-calculator';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });
    }

    const body = await req.json();
    const { originAddress, destinationAddress } = body;

    if (!originAddress || !destinationAddress) {
      return NextResponse.json(
        { error: 'Endereços de origem e destino são obrigatórios' },
        { status: 400 }
      );
    }

    // Calculate distance
    const distance = calculateDistance(originAddress, destinationAddress);

    // Calculate price
    const { price, platformFee, deliveryFee } = await calculateOrderPrice(distance);

    return NextResponse.json({
      distance,
      price,
      platformFee,
      deliveryFee,
    });
  } catch (error) {
    console.error('Error calculating price:', error);
    return NextResponse.json(
      { error: 'Erro ao calcular preço' },
      { status: 500 }
    );
  }
}
