import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import bcrypt from 'bcryptjs';
import { UserRole, UserStatus } from '@prisma/client';
import { createAuditLog } from '@/lib/audit-logger';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, password, name, role, phone, vehicleType, licenseNumber } = body;

    if (!email || !password || !name) {
      return NextResponse.json(
        { error: 'Email, senha e nome são obrigatórios' },
        { status: 400 }
      );
    }

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email },
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'Usuário já existe com este email' },
        { status: 400 }
      );
    }

    // Hash password
    const passwordHash = await bcrypt.hash(password, 10);

    // Determine user role and status
    const userRole = (role as UserRole) || UserRole.CLIENT;
    const userStatus =
      userRole === UserRole.DELIVERY_PERSON
        ? UserStatus.PENDING_APPROVAL
        : UserStatus.ACTIVE;

    // Create user
    const user = await prisma.user.create({
      data: {
        email,
        passwordHash,
        name,
        role: userRole,
        status: userStatus,
        phone: phone || null,
        vehicleType: userRole === UserRole.DELIVERY_PERSON ? vehicleType : null,
        licenseNumber: userRole === UserRole.DELIVERY_PERSON ? licenseNumber : null,
      },
    });

    // Log the signup
    await createAuditLog({
      userId: user.id,
      action: 'USER_SIGNUP',
      details: `User signed up with role: ${userRole}`,
      ipAddress: req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || undefined,
      userAgent: req.headers.get('user-agent') || undefined,
    });

    return NextResponse.json(
      {
        message:
          userRole === UserRole.DELIVERY_PERSON
            ? 'Cadastro realizado! Sua conta será aprovada em breve.'
            : 'Cadastro realizado com sucesso!',
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          status: user.status,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Signup error:', error);
    return NextResponse.json(
      { error: 'Erro ao criar conta. Tente novamente.' },
      { status: 500 }
    );
  }
}
