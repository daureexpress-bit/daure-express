import { prisma } from './db';

export async function createAuditLog({
  userId,
  orderId,
  action,
  details,
  ipAddress,
  userAgent,
}: {
  userId?: string;
  orderId?: string;
  action: string;
  details?: string;
  ipAddress?: string;
  userAgent?: string;
}) {
  try {
    await prisma.auditLog.create({
      data: {
        userId,
        orderId,
        action,
        details,
        ipAddress,
        userAgent,
      },
    });
  } catch (error) {
    console.error('Failed to create audit log:', error);
  }
}
