import { DEFAULT_SYSTEM_SETTINGS } from './constants';
import { prisma } from './db';

export async function calculateOrderPrice(distanceKm: number): Promise<{
  price: number;
  platformFee: number;
  deliveryFee: number;
}> {
  try {
    // Try to get settings from database
    const baseFeeSetting = await prisma.systemConfig.findUnique({
      where: { key: 'BASE_FEE' },
    });
    const pricePerKmSetting = await prisma.systemConfig.findUnique({
      where: { key: 'PRICE_PER_KM' },
    });
    const platformFeeSetting = await prisma.systemConfig.findUnique({
      where: { key: 'PLATFORM_FEE_PERCENTAGE' },
    });

    const baseFee = baseFeeSetting?.value
      ? parseFloat(baseFeeSetting.value)
      : DEFAULT_SYSTEM_SETTINGS.BASE_FEE;
    const pricePerKm = pricePerKmSetting?.value
      ? parseFloat(pricePerKmSetting.value)
      : DEFAULT_SYSTEM_SETTINGS.PRICE_PER_KM;
    const platformFeePercentage = platformFeeSetting?.value
      ? parseFloat(platformFeeSetting.value)
      : DEFAULT_SYSTEM_SETTINGS.PLATFORM_FEE_PERCENTAGE;

    const deliveryFee = baseFee + distanceKm * pricePerKm;
    const platformFee = deliveryFee * platformFeePercentage;
    const totalPrice = deliveryFee + platformFee;

    return {
      price: Number(totalPrice.toFixed(2)),
      platformFee: Number(platformFee.toFixed(2)),
      deliveryFee: Number(deliveryFee.toFixed(2)),
    };
  } catch (error) {
    console.error('Error calculating price:', error);
    // Fallback to default settings
    const deliveryFee =
      DEFAULT_SYSTEM_SETTINGS.BASE_FEE +
      distanceKm * DEFAULT_SYSTEM_SETTINGS.PRICE_PER_KM;
    const platformFee = deliveryFee * DEFAULT_SYSTEM_SETTINGS.PLATFORM_FEE_PERCENTAGE;
    const totalPrice = deliveryFee + platformFee;

    return {
      price: Number(totalPrice.toFixed(2)),
      platformFee: Number(platformFee.toFixed(2)),
      deliveryFee: Number(deliveryFee.toFixed(2)),
    };
  }
}

export function calculateDistance(origin: string, destination: string): number {
  // Simulated distance calculation
  // In production, integrate with Google Maps Distance Matrix API or similar
  const hash = (str: string) => {
    let h = 0;
    for (let i = 0; i < str.length; i++) {
      h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
    }
    return Math.abs(h);
  };

  const combined = origin + destination;
  const hashValue = hash(combined);
  // Generate distance between 1 and 50 km
  const distance = (hashValue % 49) + 1;
  return Number(distance.toFixed(1));
}
