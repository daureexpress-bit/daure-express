'use client';

import { signOut, useSession } from 'next-auth/react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Package,
  LayoutDashboard,
  ShoppingCart,
  Users,
  Settings,
  LogOut,
  TruckIcon,
  History,
  PlusCircle,
} from 'lucide-react';
import { UserRole } from '@prisma/client';
import { USER_ROLE_LABELS } from '@/lib/constants';

export function Navbar() {
  const [mounted, setMounted] = useState(false);
  const { data: session } = useSession() || {};
  const pathname = usePathname();

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted || !session?.user) return null;

  const userRole = session?.user?.role;

  const getNavLinks = () => {
    const baseLinks = [
      { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    ];

    if (userRole === UserRole.ADMIN) {
      return [
        ...baseLinks,
        { href: '/dashboard/orders', label: 'Pedidos', icon: ShoppingCart },
        { href: '/dashboard/users', label: 'Usuários', icon: Users },
        { href: '/dashboard/settings', label: 'Configurações', icon: Settings },
      ];
    } else if (userRole === UserRole.CLIENT) {
      return [
        ...baseLinks,
        { href: '/dashboard/new-order', label: 'Novo Pedido', icon: PlusCircle },
        { href: '/dashboard/orders', label: 'Meus Pedidos', icon: History },
      ];
    } else if (userRole === UserRole.DELIVERY_PERSON) {
      return [
        ...baseLinks,
        { href: '/dashboard/available', label: 'Disponíveis', icon: ShoppingCart },
        { href: '/dashboard/my-deliveries', label: 'Minhas Entregas', icon: TruckIcon },
      ];
    }

    return baseLinks;
  };

  const navLinks = getNavLinks();

  const handleLogout = async () => {
    await signOut({ callbackUrl: '/auth/login' });
  };

  return (
    <nav className="sticky top-0 z-50 border-b bg-white/80 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            <Link href="/dashboard" className="flex items-center space-x-2">
              <div className="rounded-full bg-gradient-to-br from-blue-500 to-orange-500 p-2">
                <Package className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-xl">DeliveryApp</span>
            </Link>

            <div className="hidden md:flex items-center space-x-1">
              {navLinks.map((link) => {
                const Icon = link.icon;
                const isActive = pathname === link.href;
                return (
                  <Link key={link.href} href={link.href}>
                    <Button
                      variant={isActive ? 'default' : 'ghost'}
                      size="sm"
                      className="flex items-center space-x-2"
                    >
                      <Icon className="w-4 h-4" />
                      <span>{link.label}</span>
                    </Button>
                  </Link>
                );
              })}
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="hidden sm:block text-sm">
              <p className="font-medium">{session?.user?.name}</p>
              <p className="text-xs text-muted-foreground">
                {USER_ROLE_LABELS[userRole as UserRole]}
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline ml-2">Sair</span>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
